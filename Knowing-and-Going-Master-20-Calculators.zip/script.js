const $=id=>document.getElementById(id);
const num=id=>Number($(id).value);
const money=x=>Number.isFinite(x)?x.toLocaleString("en-US",{style:"currency",currency:"USD"}):"—";
const fixed=x=>Number.isFinite(x)?x.toLocaleString("en-US",{maximumFractionDigits:4}):"—";
const err=(id,msg)=>$(id).innerHTML=`<span>${msg}</span>`;
function ratePayment(principal, annualRate, years){
  const n=years*12, r=annualRate/100/12;
  if(principal<0||years<=0||annualRate<0) return NaN;
  return r===0?principal/n:principal*r/(1-Math.pow(1+r,-n));
}
function calcLoan(){const p=num("loanP"),r=num("loanR"),y=num("loanY"),m=ratePayment(p,r,y); if(!Number.isFinite(m))return err("loanOut","Enter valid values."); $("loanOut").innerHTML=`Monthly payment: <b>${money(m)}</b><br>Total paid: ${money(m*y*12)}<br>Total interest: ${money(m*y*12-p)}`;}
function calcMortgage(){const price=num("mortP"),down=num("mortD"),r=num("mortR"),y=num("mortY"),p=price-down,m=ratePayment(p,r,y); if(p<0||!Number.isFinite(m))return err("mortOut","Enter valid values."); $("mortOut").innerHTML=`Amount financed: <b>${money(p)}</b><br>Monthly payment: <b>${money(m)}</b><br>Total paid: ${money(m*y*12)}`;}
function calcCompound(){const p=num("ciP"),r=num("ciR")/100,y=num("ciY"),n=num("ciN");if(p<0||r<0||y<0||n<=0)return err("ciOut","Enter valid values.");const fv=p*Math.pow(1+r/n,n*y);$("ciOut").innerHTML=`Future value: <b>${money(fv)}</b><br>Interest earned: ${money(fv-p)}`;}
function calcPaycheck(){const rate=num("payRate"),h=num("payHours"),ot=num("payOT"),d=num("payDed");if(rate<0||h<0||ot<0||d<0)return err("payOut","Enter valid values.");const gross=rate*h+rate*1.5*ot,net=gross-d;$("payOut").innerHTML=`Regular: ${money(rate*h)}<br>Overtime: ${money(rate*1.5*ot)}<br>Gross: <b>${money(gross)}</b><br>After listed deductions: <b>${money(net)}</b><small> (This does not estimate payroll taxes.)</small>`;}
function calcGas(){const m=num("gasMiles"),g=num("gasGal"),p=num("gasPrice");if(m<0||g<=0||p<0)return err("gasOut","Enter valid values.");$("gasOut").innerHTML=`Fuel economy: <b>${fixed(m/g)} MPG</b><br>Fuel cost: ${money(g*p)}<br>Cost per mile: ${money((g*p)/m)}`;}
function calcDiscount(){const p=num("discP"),r=num("discR")/100;if(p<0||r<0)return err("discOut","Enter valid values.");const save=p*r;$("discOut").innerHTML=`You save: <b>${money(save)}</b><br>Sale price: <b>${money(p-save)}</b>`;}
function calcTip(){const p=num("tipP"),r=num("tipR")/100,n=num("tipPeople");if(p<0||r<0||n<1)return err("tipOut","Enter valid values.");const tip=p*r,total=p+tip;$("tipOut").innerHTML=`Tip: <b>${money(tip)}</b><br>Total: <b>${money(total)}</b><br>Per person: ${money(total/n)}`;}
function calcPercentage(){const a=num("pctA"),b=num("pctB");if(!Number.isFinite(a)||b===0)return err("pctOut","Enter a non-zero total.");$("pctOut").innerHTML=`<b>${fixed((a/b)*100)}%</b> of ${fixed(b)}.`;}
function calcTax(){const p=num("taxP"),r=num("taxR")/100;if(p<0||r<0)return err("taxOut","Enter valid values.");const t=p*r;$("taxOut").innerHTML=`Tax: <b>${money(t)}</b><br>Total: <b>${money(p+t)}</b>`;}
function calcMarkup(){const c=num("markP"),r=num("markR")/100;if(c<0)return err("markOut","Enter valid values.");const add=c*r;$("markOut").innerHTML=`Markup: <b>${money(add)}</b><br>Selling price: <b>${money(c+add)}</b>`;}
function gcd(a,b){a=Math.abs(Math.trunc(a));b=Math.abs(Math.trunc(b));while(b){[a,b]=[b,a%b]}return a||1}
function calcRatio(){const a=num("ratioA"),b=num("ratioB"),c=num("ratioC");if(b===0||a===0)return err("ratioOut","A and B must be non-zero.");const d=c*b/a;$("ratioOut").innerHTML=`If <b>${a}:${b}</b> = <b>${c}:x</b>, then x = <b>${fixed(d)}</b>.`;}
function calcFraction(){const a=num("fA"),b=num("fB"),c=num("fC"),d=num("fD"),op=$("fOp").value;if(b===0||d===0)return err("fOut","Denominators cannot be zero.");let n,den;if(op==="+"){n=a*d+c*b;den=b*d}else if(op==="-"){n=a*d-c*b;den=b*d}else if(op==="*"){n=a*c;den=b*d}else{if(c===0)return err("fOut","Cannot divide by zero.");n=a*d;den=b*c}if(den<0){n=-n;den=-den}const g=gcd(n,den);n/=g;den/=g;$("fOut").innerHTML=`Result: <b>${n}/${den}</b> = ${fixed(n/den)}`;}
function dateVal(id){const s=$(id).value;return s?new Date(s+"T00:00:00"):null}
function calcAge(){const b=dateVal("ageBirth"),a=dateVal("ageAs")||new Date();if(!b||b>a)return err("ageOut","Enter a valid birth date.");let y=a.getFullYear()-b.getFullYear(),m=a.getMonth()-b.getMonth(),d=a.getDate()-b.getDate();if(d<0){m--;d+=new Date(a.getFullYear(),a.getMonth(),0).getDate()}if(m<0){y--;m+=12}$("ageOut").innerHTML=`Age: <b>${y} years, ${m} months, ${d} days</b>`;}
function dayDiff(s,e){return Math.round((e-s)/86400000)}
function calcDays(){const s=dateVal("daysStart"),e=dateVal("daysEnd");if(!s||!e)return err("daysOut","Choose both dates.");$("daysOut").innerHTML=`Difference: <b>${Math.abs(dayDiff(s,e))} days</b>`;}
function calcBusinessDays(){const s=dateVal("bizStart"),e=dateVal("bizEnd");if(!s||!e)return err("bizOut","Choose both dates.");let a=s<e?s:e,b=s<e?e:s,count=0;for(let d=new Date(a);d<=b;d.setDate(d.getDate()+1)){const day=d.getDay();if(day!==0&&day!==6)count++}if(s!==e){}$("bizOut").innerHTML=`Weekdays (inclusive): <b>${count}</b>`;}
function calcTemp(){const v=num("tempV"),f=$("tempFrom").value,t=$("tempTo").value;let c=f==="C"?v:f==="F"?(v-32)*5/9:v-273.15;let o=t==="C"?c:t==="F"?c*9/5+32:c+273.15;$("tempOut").innerHTML=`<b>${fixed(o)} °${t[0]}</b>`;}
function calcMiles(){const v=num("milesV");if(v<0)return err("milesOut","Enter a non-negative value.");$("milesOut").innerHTML=`${fixed(v)} miles = <b>${fixed(v*1.609344)} km</b>`;}
function calcPounds(){const v=num("poundsV");if(v<0)return err("poundsOut","Enter a non-negative value.");$("poundsOut").innerHTML=`${fixed(v)} lb = <b>${fixed(v*0.45359237)} kg</b>`;}
function calcKg(){const v=num("kgV");if(v<0)return err("kgOut","Enter a non-negative value.");$("kgOut").innerHTML=`${fixed(v)} kg = <b>${fixed(v*2.2046226218)} lb</b>`;}
function calcFeet(){const v=num("feetV");if(v<0)return err("feetOut","Enter a non-negative value.");$("feetOut").innerHTML=`${fixed(v)} ft = <b>${fixed(v*12)} in</b>`;}
function tireDiameter(w,a,r){return w*a/100/25.4*2+r*2}
function calcTires(){const a=[num("t1w"),num("t1a"),num("t1r")],b=[num("t2w"),num("t2a"),num("t2r")];if(a.some(x=>x<=0)||b.some(x=>x<=0))return err("tireOut","Enter positive tire values.");const da=tireDiameter(...a),db=tireDiameter(...b),diff=db-da,pct=diff/da*100;$("tireOut").innerHTML=`Old diameter: ${fixed(da)} in<br>New diameter: ${fixed(db)} in<br>Difference: <b>${diff>=0?"+":""}${fixed(diff)} in (${pct>=0?"+":""}${fixed(pct)}%)</b>`;}
function initDates(){const today=new Date(),iso=new Date(today.getTime()-today.getTimezoneOffset()*60000).toISOString().slice(0,10);["ageAs"].forEach(id=>$(id).value=iso);$("ageBirth").value="1990-01-01";$("daysStart").value=iso;$("daysEnd").value=iso;$("bizStart").value=iso;$("bizEnd").value=iso;}
$("search").addEventListener("input",e=>{const q=e.target.value.trim().toLowerCase();let visible=0;document.querySelectorAll(".category").forEach(cat=>{let n=0;cat.querySelectorAll(".card").forEach(c=>{const show=!q||c.dataset.name.includes(q);c.style.display=show?"":"none";if(show)n++});cat.style.display=n?"":"none";visible+=n});$("noResults").hidden=visible!==0});
initDates();
